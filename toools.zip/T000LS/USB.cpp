//
//  USB.cpp
//  T000LS
//
//  Created by Akhil Venkat on 01/10/2023.
//
#include "Header.h"
#include <stdio.h>
#include <iostream>
#include <cstdlib>
#include <string>
using namespace std;

void USB(){
    cout << "ISO Burner (Beta)" << endl;
    cout << "------------------------" << endl;
    cout << "WARNING: PROCEEDING WITH THIS PROGRAM MAY COMPLETELY DESTROY YOUR COMPUTER!!" << endl << endl;
    cout << "IMPORTANT: YOU HAVE BEEN WARNED!" << endl << endl;
    cout << "IMPORTANT: PROCEED AT YOUR OWN RISK!!!" << endl << endl;
   
  
    char platform;
    string format;
    
    cout << "Enter your platform (L)inux / (M)acOS / (W)indows:   ";
    cin >> platform;
    
    if(platform == 'L' || platform == 'l'){
        string filepath;
        cout << "Enter USB file path: ";
        cin >> filepath;
        
        int format_choice;
        cout << "Enter Drive Format: " << endl;
        cout << "1) FAT32" << endl;
        cout << "2) exFAT" << endl;
        cout << "3) NTFS" << endl;
        cout << "4) ext4" << endl;
        cout << "5) HFS+" << endl;
        cout << "6) APFS" << endl;
        cout << "7) ZFS (Coming soon...)" << endl;
        cout << "Choice: ";
        cin >> format_choice;
        
        
        if(format_choice == 1){
            format = "fat -F32 ";
        }
       else if(format_choice == 2){
            format = "exfat ";
        }
       else if(format_choice == 3){
            format = "ntfs ";
        }
       else if(format_choice == 4){
            format = "ext4 ";
        }
       else if(format_choice == 5){
            format = "hfsplus ";
        }
       else if(format_choice == 6){
            format = "apfs ";
        }
       else if(format_choice == 7){
           cout << "ZFS is coming soon..." << endl << endl;
           USB();
        }
    
        
        cout << format << endl;
        const char* usbDrive = filepath.c_str(); // USB filepath
           const char* fileSystemType = format.c_str(); // Format

           // Construct the command to format the USB drive using mkfs command
           string command = "sudo mkfs." + string(fileSystemType) + " " + string(usbDrive);

           // Execute the command to format the USB drive
           int returnValue = system(command.c_str());

           if (returnValue == 0) {
               cout << "USB drive formatted successfully." << endl;
           } else {
               cerr << "Error occurred while formatting USB drive." << endl;
           }
        
        
        
        
    }
    
    
    else if(platform == 'M' || platform == 'm'){
        
        
        string filepath;
            cout << "Enter USB file path: ";
            cin >> filepath;

            int format_choice;
            cout << "Enter Drive Format: " << endl;
            cout << "1) FAT32" << endl;
            cout << "2) exFAT" << endl;
            cout << "3) NTFS" << endl;
            cout << "4) ext4" << endl;
            cout << "5) HFS+" << endl;
            cout << "6) APFS" << endl;
            cout << "7) ZFS (Coming soon...)" << endl;
            cout << "Choice: ";
            cin >> format_choice;

            string format;
            if (format_choice == 1) {
                format = "MS-DOS FAT32";
            } else if (format_choice == 2) {
                format = "ExFAT";
            } else if (format_choice == 3) {
                format = "MS-DOS NTFS";
            } else if (format_choice == 4) {
                format = "Linux ext4";
            } else if (format_choice == 5) {
                format = "Journaled HFS+";
            } else if (format_choice == 6) {
                format = "APFS";
            } else if (format_choice == 7) {
                cout << "ZFS is coming soon..." << endl << endl;
          
            } else {
                cerr << "Invalid choice." << endl;
               
            }

        
        cout << format << endl;
            string command = "sudo diskutil eraseVolume " + format + " \"Formatted_Drive\" " + filepath;

            // Execute the command to format the USB drive
            int returnValue = system(command.c_str());

            if (returnValue == 0) {
                cout << "USB drive formatted successfully." << endl;
            } else {
                cerr << "Error occurred while formatting USB drive." << endl;
            }
        
    }
  
    
    
    
    else if(platform == 'W' || platform == 'w'){
        string driveLetter;
        cout << "Enter USB drive letter (for example, 'D:'): ";
        cin >> driveLetter;

        int format_choice;
        cout << "Enter Drive Format: " << endl;
        cout << "1) FAT32" << endl;
        cout << "2) exFAT" << endl;
        cout << "3) NTFS" << endl;
        cout << "Choice: ";
        cin >> format_choice;

        
        
        string command;
        if (format_choice == 1) {
            command = "format " + driveLetter + " /FS:FAT32";
        } else if (format_choice == 2) {
            command = "format " + driveLetter + " /FS:exFAT";
        } else if (format_choice == 3) {
            command = "format " + driveLetter + " /FS:NTFS";
        } else {
            cerr << "Invalid choice." << endl;
           
        }

        int returnValue = system(command.c_str());

        if (returnValue == 0) {
            cout << "USB drive formatted successfully." << endl;
        } else {
            cerr << "Error occurred while formatting USB drive." << endl;
        }
        
        
        
    }
    
}
