//
//  main.cpp
//  T000LS
//
//  Created by Akhil Venkat on 5/9/23.
//

#include <iostream>
#include <cstdio>
#include "Header.h"
using namespace std;
int main();

string name;
// Variables
string line = "--------------------------------";
string small_line = "----------------";

// restart

void restart(){
    cout << "Restarting..." << endl << endl << endl;
    main();
}


// Functions

void Images (){

    cout << small_line << endl;
    cout << "Convert Images" << endl;
    cout << small_line << endl;
    cout << "Choose your operation:" << endl << endl;
    
    cout << "1) JPG - PNG" << endl;
    cout << "2) PNG - JPG" << endl << endl;
    
    cout << "3) JPEG - JPG" << endl;
    cout << "4) JPG - JPEG" << endl << endl;
    
    cout << "5) PNG - JPEG" << endl;
    cout << "6) JPEG - PNG" << endl << endl;
    
    cout << "7) Custom" << endl;
    int func_choice;
    cout << "Choice: ";
    cin >> func_choice;
    
 
  
//       JPG - PNG

if(func_choice == 1){
        cout << "JPG - PNG" << endl;
        cout << "Enter image location: " << endl;
        cout << "1) Desktop" << endl;
        cout << "2) Downloads" << endl;
        cout << "3) Documents" << endl;
        cout << "4) Custom" << endl;
        int loc_choice;
        cout << "Choice: ";
        cin >> loc_choice;
    
        if(loc_choice == 1){
            cout << "Desktop" << endl;
            
            cout << "Enter file name: ";
            string filename;
            cin >> filename;
            string oldfile = "/Users/" + name + "/Desktop/" + filename + ".jpg";
              string newfile = "/Users/" + name + "/Desktop/" + filename + ".png";

              if (rename(oldfile.c_str(), newfile.c_str()) == 0) {
                  cout << "File converted successfully: " << endl;
                  cout << "From: " << oldfile << endl;
                  cout << "To: " << newfile << endl;
                  cout << "Thank you" << endl << endl;
              } else {
                  cerr << "Error: File not found." << endl << "File name: " << oldfile << endl << endl;
              }
        } // jpg - png (Desktop)
        
 else   if(loc_choice == 2){
        cout << "Downloads" << endl;
        
        cout << "Enter file name: ";
        string filename;
        cin >> filename;
        string oldfile = "/Users/" + name + "/Downloads/" + filename + ".jpg";
          string newfile = "/Users/" + name + "/Downloads/" + filename + ".png";

          if (rename(oldfile.c_str(), newfile.c_str()) == 0) {
              cout << "File converted successfully: " << endl;
              cout << "From: " << oldfile << endl;
              cout << "To: " << newfile << endl;
              cout << "Thank you" << endl << endl;
          } else {
              cerr << "Error: File not found." << endl << "File name: " << oldfile << endl << endl;
          }
    } // jpg - png (Downloads)
        
   else if(loc_choice == 3){
        cout << "Documents" << endl;
        
        cout << "Enter file name: ";
        string filename;
        cin >> filename;
        string oldfile = "/Users/" + name +"/Documents/" + filename + ".jpg";
          string newfile = "/Users/" + name + "/Documents/" + filename + ".png";

        if(rename(oldfile.c_str(), newfile.c_str()) == 0) {
              cout << "File converted successfully: " << endl;
              cout << "From: " << oldfile << endl;
              cout << "To: " << newfile << endl;
              cout << "Thank you" << endl << endl;
          } else {
              cerr << "Error: File not found." << endl << "File name: " << oldfile << endl << endl;
          }
    } // jpg - png (Documents)
        
    
    
  else  if(loc_choice == 4){
        cout << "Custom" << endl;
        string filepath;
        string newfilepath;
        cout << "Enter custom file path: ";
        cin >> filepath;
        
        cout << "Enter new file path: ";
        cin >> newfilepath;
        string oldfile = filepath;
          string newfile = newfilepath ;

          if (rename(oldfile.c_str(), newfile.c_str()) == 0) {
              cout << "File converted successfully: " << endl;
              cout << "From: " << oldfile << endl;
              cout << "To: " << newfile << endl;
              cout << "Thank you" << endl << endl;
          } else {
              cerr << "Error: File not found." << endl << "File name: " << oldfile << endl << endl;
          }
    } // JPG - PNG (custom)
        
  else{
      cout << "Please choose a valid option." << endl;
      restart();
  } // JPG - PNG (error)

    }   // Jpg - png
    
    
    
    
 //        PNG - JPG
    
    if(func_choice == 2){
            cout << "PNG - JPG" << endl;
            cout << "Enter image location: " << endl;
            cout << "1) Desktop" << endl;
            cout << "2) Downloads" << endl;
            cout << "3) Documents" << endl;
            cout << "4) Custom" << endl;
            int loc_choice;
            cout << "Choice: ";
            cin >> loc_choice;
            
            if(loc_choice == 1){
                cout << "Desktop" << endl;
                
                cout << "Enter file name: ";
                string filename;
                cin >> filename;
                string oldfile = "/Users/" + name +"/Desktop/" + filename + ".png";
                  string newfile = "/Users/" + name +"/Desktop/" + filename + ".jpg";

                  if (rename(oldfile.c_str(), newfile.c_str()) == 0) {
                      cout << "File converted successfully: " << endl;
                      cout << "From: " << oldfile << endl;
                      cout << "To: " << newfile << endl;
                      cout << "Thank you" << endl << endl;
                  } else {
                      cerr << "Error: File not found." << endl << "File name: " << oldfile << endl << endl;
                  }
            } // png - jpg (Desktop)
            
     else   if(loc_choice == 2){
            cout << "Downloads" << endl;
            
            cout << "Enter file name: ";
            string filename;
            cin >> filename;
            string oldfile = "/Users/" + name +"/Downloads/" + filename + ".png";
              string newfile = "/Users/" + name + "/Downloads/" + filename + ".jpg";

              if (rename(oldfile.c_str(), newfile.c_str()) == 0) {
                  cout << "File converted successfully: " << endl;
                  cout << "From: " << oldfile << endl;
                  cout << "To: " << newfile << endl;
                  cout << "Thank you" << endl << endl;
              } else {
                  cerr << "Error: File not found." << endl << "File name: " << oldfile << endl << endl;
              }
        } // png - jpg (Downloads)
            
       else if(loc_choice == 3){
            cout << "Documents" << endl;
            
            cout << "Enter file name: ";
            string filename;
            cin >> filename;
            string oldfile = "/Users/" + name + "/Documents/" + filename + ".png";
              string newfile = "/Users/" + name +"/Documents/" + filename + ".jpg";

            if(rename(oldfile.c_str(), newfile.c_str()) == 0) {
                  cout << "File converted successfully: " << endl;
                  cout << "From: " << oldfile << endl;
                  cout << "To: " << newfile << endl;
                  cout << "Thank you" << endl << endl;
              } else {
                  cerr << "Error: File not found." << endl << "File name: " << oldfile << endl << endl;
              }
        } // png - jpg (Documents)
            
        
        
      else  if(loc_choice == 4){
            cout << "Custom" << endl;
            string filepath;
            string newfilepath;
            cout << "Enter custom file path: ";
            cin >> filepath;
            
            cout << "Enter new file path: ";
            cin >> newfilepath;
            string oldfile = filepath;
              string newfile = newfilepath ;

              if (rename(oldfile.c_str(), newfile.c_str()) == 0) {
                  cout << "File converted successfully: " << endl;
                  cout << "From: " << oldfile << endl;
                  cout << "To: " << newfile << endl;
                  cout << "Thank you" << endl << endl;
              } else {
                  cerr << "Error: File not found." << endl << "File name: " << oldfile << endl << endl;
              }
        } // png - jpg (custom)
            
      else{
          cout << "Please choose a valid option." << endl;
          restart();
      } // png - jpg (error)

        }   // png - jpg
    
 
    
 //            JPEG - JPG
    
    if(func_choice == 3){
            cout << "JPEG - JPG" << endl;
            cout << "Enter image location: " << endl;
            cout << "1) Desktop" << endl;
            cout << "2) Downloads" << endl;
            cout << "3) Documents" << endl;
            cout << "4) Custom" << endl;
            int loc_choice;
            cout << "Choice: ";
            cin >> loc_choice;
            
            if(loc_choice == 1){
                cout << "Desktop" << endl;
                
                cout << "Enter file name: ";
                string filename;
                cin >> filename;
                string oldfile = "/Users/" + name +"/Desktop/" + filename + ".jpeg";
                  string newfile = "/Users/" + name +"/Desktop/" + filename + ".jpg";

                  if (rename(oldfile.c_str(), newfile.c_str()) == 0) {
                      cout << "File converted successfully: " << endl;
                      cout << "From: " << oldfile << endl;
                      cout << "To: " << newfile << endl;
                      cout << "Thank you" << endl << endl;
                  } else {
                      cerr << "Error: File not found." << endl << "File name: " << oldfile << endl << endl;
                  }
            } // jpeg - jpg (Desktop)
            
     else   if(loc_choice == 2){
            cout << "Downloads" << endl;
            
            cout << "Enter file name: ";
            string filename;
            cin >> filename;
            string oldfile = "/Users/" + name + "/Downloads/" + filename + ".jpeg";
              string newfile = "/Users/"+ name +"/Downloads/" + filename + ".jpg";

              if (rename(oldfile.c_str(), newfile.c_str()) == 0) {
                  cout << "File converted successfully: " << endl;
                  cout << "From: " << oldfile << endl;
                  cout << "To: " << newfile << endl;
                  cout << "Thank you" << endl << endl;
              } else {
                  cerr << "Error: File not found." << endl << "File name: " << oldfile << endl << endl;
              }
        } // jpeg - jpg (Downloads)
            
       else if(loc_choice == 3){
            cout << "Documents" << endl;
            
            cout << "Enter file name: ";
            string filename;
            cin >> filename;
            string oldfile = "/Users/" + name +"/Documents/" + filename + ".jpeg";
              string newfile = "/Users/" + name +"/Documents/" + filename + ".jpg";

            if(rename(oldfile.c_str(), newfile.c_str()) == 0) {
                  cout << "File converted successfully: " << endl;
                  cout << "From: " << oldfile << endl;
                  cout << "To: " << newfile << endl;
                  cout << "Thank you" << endl << endl;
              } else {
                  cerr << "Error: File not found." << endl << "File name: " << oldfile << endl << endl;
              }
        } // jpeg - jpg (Documents)
            
        
        
      else  if(loc_choice == 4){
            cout << "Custom" << endl;
            string filepath;
            string newfilepath;
            cout << "Enter custom file path: ";
            cin >> filepath;
            
            cout << "Enter new file path: ";
            cin >> newfilepath;
            string oldfile = filepath;
              string newfile = newfilepath ;

              if (rename(oldfile.c_str(), newfile.c_str()) == 0) {
                  cout << "File converted successfully: " << endl;
                  cout << "From: " << oldfile << endl;
                  cout << "To: " << newfile << endl;
                  cout << "Thank you" << endl << endl;
              } else {
                  cerr << "Error: File not found." << endl << "File name: " << oldfile << endl << endl;
              }
        } // JPeg - jpg (custom)
            
      else{
          cout << "Please choose a valid option." << endl;
          restart();
      } // Jpeg - jpg (error)

        }   // jpeg - jpg
    
    
    
    
    //            JPG - JPEG
       
       if(func_choice == 4){
               cout << "JPG - JPEG" << endl;
               cout << "Enter image location: " << endl;
               cout << "1) Desktop" << endl;
               cout << "2) Downloads" << endl;
               cout << "3) Documents" << endl;
               cout << "4) Custom" << endl;
               int loc_choice;
               cout << "Choice: ";
               cin >> loc_choice;
               
               if(loc_choice == 1){
                   cout << "Desktop" << endl;
                   
                   cout << "Enter file name: ";
                   string filename;
                   cin >> filename;
                   string oldfile = "/Users/" + name +"/Desktop/" + filename + ".jpg";
                     string newfile = "/Users/" + name +"/Desktop/" + filename + ".jpeg";

                     if (rename(oldfile.c_str(), newfile.c_str()) == 0) {
                         cout << "File converted successfully: " << endl;
                         cout << "From: " << oldfile << endl;
                         cout << "To: " << newfile << endl;
                         cout << "Thank you" << endl << endl;
                     } else {
                         cerr << "Error: File not found." << endl << "File name: " << oldfile << endl << endl;
                     }
               } // jpg - jpeg (Desktop)
               
        else   if(loc_choice == 2){
               cout << "Downloads" << endl;
               
               cout << "Enter file name: ";
               string filename;
               cin >> filename;
               string oldfile = "/Users/" + name +"/Downloads/" + filename + ".jpg";
                 string newfile = "/Users/" + name +"/Downloads/" + filename + ".jpeg";

                 if (rename(oldfile.c_str(), newfile.c_str()) == 0) {
                     cout << "File converted successfully: " << endl;
                     cout << "From: " << oldfile << endl;
                     cout << "To: " << newfile << endl;
                     cout << "Thank you" << endl << endl;
                 } else {
                     cerr << "Error: File not found." << endl << "File name: " << oldfile << endl << endl;
                 }
           } // jpg - jpeg (Downloads)
               
          else if(loc_choice == 3){
               cout << "Documents" << endl;
               
               cout << "Enter file name: ";
               string filename;
               cin >> filename;
               string oldfile = "/Users/" + name +"/Documents/" + filename + ".jpg";
                 string newfile = "/Users/" + name +"/Documents/" + filename + ".jpeg";

               if(rename(oldfile.c_str(), newfile.c_str()) == 0) {
                     cout << "File converted successfully: " << endl;
                     cout << "From: " << oldfile << endl;
                     cout << "To: " << newfile << endl;
                     cout << "Thank you" << endl << endl;
                 } else {
                     cerr << "Error: File not found." << endl << "File name: " << oldfile << endl << endl;
                 }
           } // jpg - jpeg (Documents)
               
           
           
         else  if(loc_choice == 4){
               cout << "Custom" << endl;
               string filepath;
               string newfilepath;
               cout << "Enter custom file path: ";
               cin >> filepath;
               
               cout << "Enter new file path: ";
               cin >> newfilepath;
               string oldfile = filepath;
                 string newfile = newfilepath ;

                 if (rename(oldfile.c_str(), newfile.c_str()) == 0) {
                     cout << "File converted successfully: " << endl;
                     cout << "From: " << oldfile << endl;
                     cout << "To: " << newfile << endl;
                     cout << "Thank you" << endl << endl;
                 } else {
                     cerr << "Error: File not found." << endl << "File name: " << oldfile << endl << endl;
                 }
           } // JPg - jpeg (custom)
               
         else{
             cout << "Please choose a valid option." << endl;
             restart();
         } // Jpg - jpeg (error)

           }   // jpg - jpeg
       
       
    
    
    
    
    //            PNG - JPEG
       
       if(func_choice == 5){
               cout << "PNG - JPEG" << endl;
               cout << "Enter image location: " << endl;
               cout << "1) Desktop" << endl;
               cout << "2) Downloads" << endl;
               cout << "3) Documents" << endl;
               cout << "4) Custom" << endl;
               int loc_choice;
               cout << "Choice: ";
               cin >> loc_choice;
               
               if(loc_choice == 1){
                   cout << "Desktop" << endl;
                   
                   cout << "Enter file name: ";
                   string filename;
                   cin >> filename;
                   string oldfile = "/Users/" + name +"/Desktop/" + filename + ".png";
                     string newfile = "/Users/" + name +"/Desktop/" + filename + ".jpeg";

                     if (rename(oldfile.c_str(), newfile.c_str()) == 0) {
                         cout << "File converted successfully: " << endl;
                         cout << "From: " << oldfile << endl;
                         cout << "To: " << newfile << endl;
                         cout << "Thank you" << endl << endl;
                     } else {
                         cerr << "Error: File not found." << endl << "File name: " << oldfile << endl << endl;
                     }
               } // png - jpeg (Desktop)
               
        else   if(loc_choice == 2){
               cout << "Downloads" << endl;
               
               cout << "Enter file name: ";
               string filename;
               cin >> filename;
               string oldfile = "/Users/" + name +"/Downloads/" + filename + ".png";
                 string newfile = "/Users/" + name +"/Downloads/" + filename + ".jpeg";

                 if (rename(oldfile.c_str(), newfile.c_str()) == 0) {
                     cout << "File converted successfully: " << endl;
                     cout << "From: " << oldfile << endl;
                     cout << "To: " << newfile << endl;
                     cout << "Thank you" << endl << endl;
                 } else {
                     cerr << "Error: File not found." << endl << "File name: " << oldfile << endl << endl;
                 }
           } // png - jpeg (Downloads)
               
          else if(loc_choice == 3){
               cout << "Documents" << endl;
               
               cout << "Enter file name: ";
               string filename;
               cin >> filename;
               string oldfile = "/Users/" + name +"/Documents/" + filename + ".png";
                 string newfile = "/Users/" + name +"/Documents/" + filename + ".jpeg";

               if(rename(oldfile.c_str(), newfile.c_str()) == 0) {
                     cout << "File converted successfully: " << endl;
                     cout << "From: " << oldfile << endl;
                     cout << "To: " << newfile << endl;
                     cout << "Thank you" << endl << endl;
                 } else {
                     cerr << "Error: File not found." << endl << "File name: " << oldfile << endl << endl;
                 }
           } // png - jpeg (Documents)
               
           
           
         else  if(loc_choice == 4){
               cout << "Custom" << endl;
               string filepath;
               string newfilepath;
               cout << "Enter custom file path: ";
               cin >> filepath;
               
               cout << "Enter new file path: ";
               cin >> newfilepath;
               string oldfile = filepath;
                 string newfile = newfilepath ;

                 if (rename(oldfile.c_str(), newfile.c_str()) == 0) {
                     cout << "File converted successfully: " << endl;
                     cout << "From: " << oldfile << endl;
                     cout << "To: " << newfile << endl;
                     cout << "Thank you" << endl << endl;
                 } else {
                     cerr << "Error: File not found." << endl << "File name: " << oldfile << endl << endl;
                 }
           } // png - jpeg (custom)
               
         else{
             cout << "Please choose a valid option." << endl;
             restart();
         } // png - jpeg (error)

           }   // png - jpeg
       
       
    
    
    
    
    
    //            JPEG - PNG
       
       if(func_choice == 6){
               cout << "JPEG - PNG" << endl;
               cout << "Enter image location: " << endl;
               cout << "1) Desktop" << endl;
               cout << "2) Downloads" << endl;
               cout << "3) Documents" << endl;
               cout << "4) Custom" << endl;
               int loc_choice;
               cout << "Choice: ";
               cin >> loc_choice;
               
               if(loc_choice == 1){
                   cout << "Desktop" << endl;
                   
                   cout << "Enter file name: ";
                   string filename;
                   cin >> filename;
                   string oldfile = "/Users/" + name +"/Desktop/" + filename + ".jpeg";
                     string newfile = "/Users/" + name +"/Desktop/" + filename + ".png";

                     if (rename(oldfile.c_str(), newfile.c_str()) == 0) {
                         cout << "File converted successfully: " << endl;
                         cout << "From: " << oldfile << endl;
                         cout << "To: " << newfile << endl;
                         cout << "Thank you" << endl << endl;
                     } else {
                         cerr << "Error: File not found." << endl << "File name: " << oldfile << endl << endl;
                     }
               } // jpeg - png (Desktop)
               
        else   if(loc_choice == 2){
               cout << "Downloads" << endl;
               
               cout << "Enter file name: ";
               string filename;
               cin >> filename;
               string oldfile = "/Users/" + name +"/Downloads/" + filename + ".jpeg";
                 string newfile = "/Users/" + name +"/Downloads/" + filename + ".png";

                 if (rename(oldfile.c_str(), newfile.c_str()) == 0) {
                     cout << "File converted successfully: " << endl;
                     cout << "From: " << oldfile << endl;
                     cout << "To: " << newfile << endl;
                     cout << "Thank you" << endl << endl;
                 } else {
                     cerr << "Error: File not found." << endl << "File name: " << oldfile << endl << endl;
                 }
           } // jpeg - png (Downloads)
               
          else if(loc_choice == 3){
               cout << "Documents" << endl;
               
               cout << "Enter file name: ";
               string filename;
               cin >> filename;
               string oldfile = "/Users/" + name +"/Documents/" + filename + ".jpeg";
                 string newfile = "/Users/" + name + "/Documents/" + filename + ".png";

               if(rename(oldfile.c_str(), newfile.c_str()) == 0) {
                     cout << "File converted successfully: " << endl;
                     cout << "From: " << oldfile << endl;
                     cout << "To: " << newfile << endl;
                     cout << "Thank you" << endl << endl;
                 } else {
                     cerr << "Error: File not found." << endl << "File name: " << oldfile << endl << endl;
                 }
           } // jpeg - png (Documents)
               
           
           
         else  if(loc_choice == 4){
               cout << "Custom" << endl;
               string filepath;
               string newfilepath;
               cout << "Enter custom file path: ";
               cin >> filepath;
               
               cout << "Enter new file path: ";
               cin >> newfilepath;
               string oldfile = filepath;
                 string newfile = newfilepath ;

                 if (rename(oldfile.c_str(), newfile.c_str()) == 0) {
                     cout << "File converted successfully: " << endl;
                     cout << "From: " << oldfile << endl;
                     cout << "To: " << newfile << endl;
                     cout << "Thank you" << endl << endl;
                 } else {
                     cerr << "Error: File not found." << endl << "File name: " << oldfile << endl << endl;
                 }
           } // jpeg - png (custom)
               
         else{
             cout << "Please choose a valid option." << endl;
             restart();
         } // jpeg - png (error)

           }   // jpeg - png
       
       
//      Custom images
       else if(func_choice == 7){
           cout << "Custom" << endl;
           string filepath;
           string newfilepath;
           cout << "Enter custom file path: ";
           cin >> filepath;
           
           cout << "Enter new file path: ";
           cin >> newfilepath;
           string oldfile = filepath;
             string newfile = newfilepath ;

             if (rename(oldfile.c_str(), newfile.c_str()) == 0) {
                 cout << "File converted successfully: " << endl;
                 cout << "From: " << oldfile << endl;
                 cout << "To: " << newfile << endl;
                 cout << "Thank you" << endl << endl;
             } else {
                 cerr << "Error: File not found." << endl << "File name: " << oldfile << endl << endl;
             }
       } // custom
    
   
       else if (func_choice > 7){
           cout << "Please choose from the given choices" << endl;
           Images();
       } //out of range option
        
    
}   // image





void video (){
    
    cout << small_line << endl;
    cout << "Convert Videos" << endl;
    cout << small_line << endl;
    cout << "Choose your operation:" << endl << endl;
    
    cout << "1) MOV - MP4" << endl;
    cout << "2) MP4 - MOV" << endl ;
    cout << "3) FLV - MP4" << endl;
    cout << "4) Custom" << endl;
    int func_choice;
    cout << "Choice: ";
    cin >> func_choice;
    
    
    if(func_choice == 1){
        cout << "MOV - MP4" << endl;
        cout << "Enter video location: " << endl;
        cout << "1) Desktop" << endl;
        cout << "2) Downloads" << endl;
        cout << "3) Documents" << endl;
        cout << "4) Custom" << endl;
        int loc_choice;
        cout << "Choice: ";
        cin >> loc_choice;
        
        if(loc_choice == 1){
            cout << "Desktop" << endl;
            
            cout << "Enter file name: ";
            string filename;
            cin >> filename;
            string oldfile = "/Users/" + name +"/Desktop/" + filename + ".mov";
            string newfile = "/Users/" + name +"/Desktop/" + filename + ".mp4";
            
            if (rename(oldfile.c_str(), newfile.c_str()) == 0) {
                cout << "File converted successfully: " << endl;
                cout << "From: " << oldfile << endl;
                cout << "To: " << newfile << endl;
                cout << "Thank you" << endl << endl;
            } else {
                cerr << "Error: File not found." << endl << "File name: " << oldfile << endl << endl;
            }
            
        }  // mov - mp4 (Dsktop)
        
        if(loc_choice == 2){
            cout << "Downloads" << endl;
            
            cout << "Enter file name: ";
            string filename;
            cin >> filename;
            string oldfile = "/Users/" + name +"/Downloads/" + filename + ".mov";
            string newfile = "/Users/" + name +"/Downloads/" + filename + ".mp4";
            
            if (rename(oldfile.c_str(), newfile.c_str()) == 0) {
                cout << "File converted successfully: " << endl;
                cout << "From: " << oldfile << endl;
                cout << "To: " << newfile << endl;
                cout << "Thank you" << endl << endl;
            } else {
                cerr << "Error: File not found." << endl << "File name: " << oldfile << endl << endl;
            }
            
        }  // mov - mp4 (Downloads)
        
        
        if(loc_choice == 3){
            cout << "Documents" << endl;
            
            cout << "Enter file name: ";
            string filename;
            cin >> filename;
            string oldfile = "/Users/" + name +"/Documents/" + filename + ".mov";
            string newfile = "/Users/" + name +"/Documents/" + filename + ".mp4";
            
            if (rename(oldfile.c_str(), newfile.c_str()) == 0) {
                cout << "File converted successfully: " << endl;
                cout << "From: " << oldfile << endl;
                cout << "To: " << newfile << endl;
                cout << "Thank you" << endl << endl;
            } else {
                cerr << "Error: File not found." << endl << "File name: " << oldfile << endl << endl;
            }
            
        }  // mov - mp4 (Documents)
        
        
        else if(loc_choice == 4){
            cout << "Custom" << endl;
            string filepath;
            string newfilepath;
            cout << "Enter custom file path: ";
            cin >> filepath;
            
            cout << "Enter new file path: ";
            cin >> newfilepath;
            string oldfile = filepath;
              string newfile = newfilepath ;

              if (rename(oldfile.c_str(), newfile.c_str()) == 0) {
                  cout << "File converted successfully: " << endl;
                  cout << "From: " << oldfile << endl;
                  cout << "To: " << newfile << endl;
                  cout << "Thank you" << endl << endl;
              } else {
                  cerr << "Error: File not found." << endl << "File name: " << oldfile << endl << endl;
              }
        } // mov - mp4 (Custom)
        
    } // mov - mp4
    
    
   else if(func_choice == 2){
        cout << "MP4 - MOV" << endl;
        cout << "Enter video location: " << endl;
        cout << "1) Desktop" << endl;
        cout << "2) Downloads" << endl;
        cout << "3) Documents" << endl;
        cout << "4) Custom" << endl;
        int loc_choice;
        cout << "Choice: ";
        cin >> loc_choice;
        
        if(loc_choice == 1){
            cout << "Desktop" << endl;
            
            cout << "Enter file name: ";
            string filename;
            cin >> filename;
            string oldfile = "/Users/" + name +"/Desktop/" + filename + ".mp4";
            string newfile = "/Users/" + name +"/Desktop/" + filename + ".mov";
            
            if (rename(oldfile.c_str(), newfile.c_str()) == 0) {
                cout << "File converted successfully: " << endl;
                cout << "From: " << oldfile << endl;
                cout << "To: " << newfile << endl;
                cout << "Thank you" << endl << endl;
            } else {
                cerr << "Error: File not found." << endl << "File name: " << oldfile << endl << endl;
            }
            
        }  // mp4 - mov (Dsktop)
        
        if(loc_choice == 2){
            cout << "Downloads" << endl;
            
            cout << "Enter file name: ";
            string filename;
            cin >> filename;
            string oldfile = "/Users/" + name +"/Downloads/" + filename + ".mp4";
            string newfile = "/Users/" + name +"/Downloads/" + filename + ".mov";
            
            if (rename(oldfile.c_str(), newfile.c_str()) == 0) {
                cout << "File converted successfully: " << endl;
                cout << "From: " << oldfile << endl;
                cout << "To: " << newfile << endl;
                cout << "Thank you" << endl << endl;
            } else {
                cerr << "Error: File not found." << endl << "File name: " << oldfile << endl << endl;
            }
            
        }  // mp4 - mov (Downloads)
        
        
        if(loc_choice == 3){
            cout << "Documents" << endl;
            
            cout << "Enter file name: ";
            string filename;
            cin >> filename;
            string oldfile = "/Users/" + name +"/Documents/" + filename + ".mp4";
            string newfile = "/Users/" + name +"/Documents/" + filename + ".mov";
            
            if (rename(oldfile.c_str(), newfile.c_str()) == 0) {
                cout << "File converted successfully: " << endl;
                cout << "From: " << oldfile << endl;
                cout << "To: " << newfile << endl;
                cout << "Thank you" << endl << endl;
            } else {
                cerr << "Error: File not found." << endl << "File name: " << oldfile << endl << endl;
            }
            
        }  // mp4 - mov (Documents)
        
        
        else if(func_choice == 4){
            cout << "Custom" << endl;
            string filepath;
            string newfilepath;
            cout << "Enter custom file path: ";
            cin >> filepath;
            
            cout << "Enter new file path: ";
            cin >> newfilepath;
            string oldfile = filepath;
              string newfile = newfilepath ;

              if (rename(oldfile.c_str(), newfile.c_str()) == 0) {
                  cout << "File converted successfully: " << endl;
                  cout << "From: " << oldfile << endl;
                  cout << "To: " << newfile << endl;
                  cout << "Thank you" << endl << endl;
              } else {
                  cerr << "Error: File not found." << endl << "File name: " << oldfile << endl << endl;
              }
        } // mp4 - mov (Custom)
        
    } // mp4 - mov
    
    
    
   else if(func_choice == 3){
        cout << "FLV - MP4" << endl;
        cout << "Enter video location: " << endl;
        cout << "1) Desktop" << endl;
        cout << "2) Downloads" << endl;
        cout << "3) Documents" << endl;
        cout << "4) Custom" << endl;
        int loc_choice;
        cout << "Choice: ";
        cin >> loc_choice;
        
        if(loc_choice == 1){
            cout << "Desktop" << endl;
            
            cout << "Enter file name: ";
            string filename;
            cin >> filename;
            string oldfile = "/Users/" + name +"/Desktop/" + filename + ".flv";
            string newfile = "/Users/" + name +"/Desktop/" + filename + ".mp4";
            
            if (rename(oldfile.c_str(), newfile.c_str()) == 0) {
                cout << "File converted successfully: " << endl;
                cout << "From: " << oldfile << endl;
                cout << "To: " << newfile << endl;
                cout << "Thank you" << endl << endl;
            } else {
                cerr << "Error: File not found." << endl << "File name: " << oldfile << endl << endl;
            }
            
        }  // flv - mp4 (Dsktop)
        
        if(loc_choice == 2){
            cout << "Downloads" << endl;
            
            cout << "Enter file name: ";
            string filename;
            cin >> filename;
            string oldfile = "/Users/" + name +"/Downloads/" + filename + ".flv";
            string newfile = "/Users/" + name +"/Downloads/" + filename + ".mp4";
            
            if (rename(oldfile.c_str(), newfile.c_str()) == 0) {
                cout << "File converted successfully: " << endl;
                cout << "From: " << oldfile << endl;
                cout << "To: " << newfile << endl;
                cout << "Thank you" << endl << endl;
            } else {
                cerr << "Error: File not found." << endl << "File name: " << oldfile << endl << endl;
            }
            
        }  // flv - mp4 (Downloads)
        
        
        if(loc_choice == 3){
            cout << "Documents" << endl;
            
            cout << "Enter file name: ";
            string filename;
            cin >> filename;
            string oldfile = "/Users/" + name +"/Documents/" + filename + ".flv";
            string newfile = "/Users/" + name +"/Documents/" + filename + ".mp4";
            
            if (rename(oldfile.c_str(), newfile.c_str()) == 0) {
                cout << "File converted successfully: " << endl;
                cout << "From: " << oldfile << endl;
                cout << "To: " << newfile << endl;
                cout << "Thank you" << endl << endl;
            } else {
                cerr << "Error: File not found." << endl << "File name: " << oldfile << endl << endl;
            }
            
        }  // flv - mp4 (Documents)
        
        
        else if(func_choice == 4){
            cout << "Custom" << endl;
            string filepath;
            string newfilepath;
            cout << "Enter custom file path: ";
            cin >> filepath;
            
            cout << "Enter new file path: ";
            cin >> newfilepath;
            string oldfile = filepath;
              string newfile = newfilepath ;

              if (rename(oldfile.c_str(), newfile.c_str()) == 0) {
                  cout << "File converted successfully: " << endl;
                  cout << "From: " << oldfile << endl;
                  cout << "To: " << newfile << endl;
                  cout << "Thank you" << endl << endl;
              } else {
                  cerr << "Error: File not found." << endl << "File name: " << oldfile << endl << endl;
              }
        } // flv - mp4 (Custom)
        
    } // flv - mp4
    
    
   else if(func_choice == 4){
       cout << "Custom" << endl;
       string filepath;
       string newfilepath;
       cout << "Enter custom file path: ";
       cin >> filepath;
       
       cout << "Enter new file path: ";
       cin >> newfilepath;
       string oldfile = filepath;
         string newfile = newfilepath ;

         if (rename(oldfile.c_str(), newfile.c_str()) == 0) {
             cout << "File converted successfully: " << endl;
             cout << "From: " << oldfile << endl;
             cout << "To: " << newfile << endl;
             cout << "Thank you" << endl << endl;
         } else {
             cerr << "Error: File not found." << endl << "File name: " << oldfile << endl << endl;
         }
   } // video custom
    
    
   else if(func_choice > 4){
       cout << "Please choose from the given choices" << endl;
       video();
   } //out of range option
    
    
} // video
    
    
void application(){
    int func_choice;
    cout << "Applications" << endl;
    cout << line << endl;
    cout << "Choose your application:" << endl;
    cout << line << endl;
    
    cout << "1) ISO Burner" << endl;
    cout << "2) USB Formater" << endl;
    cout << "3) Encryptor" << endl;
    cout << "4) Calculator" << endl;
    cout << "More coming soon..." << endl;
    cout << "Choice: ";
    cin >> func_choice;
    cout << line << endl;
    
    if(func_choice == 1 ){
        ISO();
        
    } // ISO
    
    
    
    else if(func_choice == 2 ){
        
        USB();
    } //USB

   else if(func_choice == 3 ){
        cout << "Encryptor:" << endl;
       encryptor();
    }
   else if(func_choice == 4 ){
        cout << "Calculator:" << endl;
       calc();
    }
    
} // applications
    
    
    
void helpdesk(){
    cout << "Help Desk" << endl;
    cout << "Help Desk coming soon..." << endl;
    main();
    
} // Help Desk

    
    
    
    
    int main() {
        cout << "Enter your name: ";
        cin >> name;
        cout << line << endl;
        cout << "Hello " + name + ", welcome to T000LS" << endl;
        cout << line << endl;
        cout << "Choose your operation:" << endl;
        
        cout << "1) Convert Images" << endl;
        cout << "2) Convert Videos" << endl;
        cout << "3) Applications" << endl;
        cout << "0) Help Desk" << endl;
        cout << line << endl;
        int choice_main;
        cout << "Choice: ";
        cin >> choice_main;
        
        if(choice_main == 1){
            Images();
        }
        
        else if(choice_main == 2 ){
            video();
        }
        else if(choice_main == 3){
            application();
        }
        else if(choice_main == 0){
            helpdesk();
        }
    
        return 0;
    }







