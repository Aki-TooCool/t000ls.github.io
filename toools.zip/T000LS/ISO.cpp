//
//  ISO.cpp
//  T000LS
//
//  Created by Akhil Venkat on 7/9/23.
//

#include <stdio.h>
#include <iostream>
#include <cstdlib>
#include "Header.h"
using namespace std;
void ISO() {
    
    cout << "ISO Burner (Beta)" << endl;
    cout << "------------------------" << endl;
    cout << "WARNING: PROCEEDING WITH THIS PROGRAM MAY COMPLETELY DESTROY YOUR COMPUTER!!" << endl << endl;
    cout << "IMPORTANT: YOU HAVE BEEN WARNED!" << endl << endl;
    cout << "IMPORTANT: PROCEED AT YOUR OWN RISK!!!" << endl << endl;
    
    string isofile;
    string usbpath;
    string choice;
    
    cout << "ISO file Path: ";
    cin >> isofile;
    cout << endl << "USB Path: ";
    cin >> usbpath;
    cout << "WARNING: ARE YOU SURE YOU WANT TO PROCEED?(YeS/No) ";
    cin >> choice;
    if(choice == "YeS"){
        cout << "Proceeding..." << endl;
        const char* isoFilePath = isofile.c_str();
        const char* usbDrivePath = usbpath.c_str();
        
        // Construct the dd command
        string ddCommand = "sudo dd if=" + string(isoFilePath) + " of=" + string(usbDrivePath) + " bs=4M status=progress && sync";
        
        // Execute the dd command using system call
        int result = system(ddCommand.c_str());
        
        if (result == 0) {
            cout << "ISO burned successfully to " << usbDrivePath << endl;
        } else {
            cerr << "Error burning ISO to " << usbDrivePath << endl;
        }
    }

}


