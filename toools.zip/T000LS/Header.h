//
//  header
//  T000LS
//
//  Created by Akhil Venkat on 7/9/23.
//

#ifndef Header_h
#define Header_h

#include <stdio.h>

void encryptor();
void encrypt();
void decrypt();
void calc();
void ISO();
void USB();
#endif /* Header.H*/



