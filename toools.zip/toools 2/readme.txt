Hello! Welcome to T000LS :D

Thank you for downloading T000LS.

T000LS is a small project made up of 4 .cpp files and 1 header file.
To compile T000LS for your computer, please follow the steps given below for you operating system.

*Official windows support to be added later during beta release.


################# Build Instructions ##########################

*** MacOS ***
1) Copy all files (Excluding this readme file) in this .zip to the desktop.

2) open terminal and type the following commands:
	
	% cd Desktop 
	
	% clang++ -c main.cpp -o main.o
	% clang++ -c ISO.cpp -o iso.o
	% clang++ -c encryptor.cpp -o encryptor.o
 	% clang++ -c encryptor.hpp header.o
	% clang++ -c calculator.cpp -o calculator.o
		

	% clang++ main.o iso.o encryptor.o header.o caclulator.o -o T000LS

###### DO not copy the percent "%" symbol. ##########


* The following commands compile the .cpp & header file and create an executable

3) Run the executable and enjoy :)
	./ T000LS



*** Linux ***
1) Copy all files (Excluding this readme file) in this .zip to the desktop.

2) open terminal and type the following commands:

	$ cd Desktop

        $ gcc++ -c main.cpp -o main.o
        $ gcc++ -c ISO.cpp -o iso.o
        $ gcc++ -c encryptor.cpp -o encryptor.o
        $ gcc++ -c encryptor.hpp header.o
        $ gcc++ -c calculator.cpp -o calculator.o


        $ gcc++ main.o iso.o encryptor.o header.o caclulator.o -o T000LS

##### Do not copy the dollar symbol "$". ########

* The following commands compile the .cpp & header file and create an executable

3) Run the executable and enjoy :)
	./ T000LS





*** Windows ***

* Coming soon!



Donate to the creator: 
BTC:  bc1ql2wyp9w02qfgzzyw6sawr09sl2qelf70706y0g
ETH/USDT:  ...



