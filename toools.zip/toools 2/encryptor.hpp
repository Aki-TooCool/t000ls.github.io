//
//  encryptor.hpp
//  T000LS
//
//  Created by Akhil Venkat on 7/9/23.
//

#ifndef encryptor_hpp
#define encryptor_hpp

#include <stdio.h>

void encryptor();
void encrypt();
void decrypt();
void calc();
void ISO();
#endif /* encryptor_hpp */


