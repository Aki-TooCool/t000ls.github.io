 
inpt = str(input())
count = 0

inp = inpt.replace(" ", "")
# Removing the space cuz not needed
for x in inp:
    count += 1

print(count)
